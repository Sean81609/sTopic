package jdbcUtil;

import java.sql.Connection;

public interface ConnectionUtil {//功能

	//方法
	//-取得連線
	Connection getConnection();
	//-清理環境
	boolean free();//可以是void
}
