package GetAndExport;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import jdbcUtil.ConnectionUtil;
import jdbcUtil.impl.ConnectionUtilImpl;

public class exportData {

	public static void main(String[] args) {
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement("SELECT *\r\n"
					+ "FROM [STopic].[dbo].[assist_data]    ");
			ResultSet rs = pstmt.executeQuery();
			
			//////////////取得SQL欄位名稱//////////////
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int ColumnNumber = rsmd.getColumnCount();
			//System.out.println("欄位個數:" + ColumnNumber);
			String[] ColumnName = new String[ColumnNumber]; //建立欄位名稱表
			for (int i = 1; i<= ColumnNumber; i++)
			{
			      ColumnName[i-1] = rsmd.getColumnName(i);
			      System.out.print(ColumnName[i-1]+" ");
			    
			}
			System.out.println();//換行
			
			//////////////取得SQL欄位名稱//////////////
			
			
			
			while(rs.next()) {
				 
				System.out.print(rs.getString(1)+" ");
				System.out.print(rs.getString(2)+" ");
				System.out.print(rs.getInt(3)+" ");
				System.out.print(rs.getString(4)+" ");
				System.out.print(rs.getString(5)+" ");
				System.out.print(rs.getString(6)+" ");
				System.out.print(rs.getString(7)+" ");
				System.out.println(rs.getDate(8));
			}
			rs.close();
			connUtil.free();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
