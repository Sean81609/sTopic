package GetAndExport;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jdbcUtil.ConnectionUtil;
import jdbcUtil.impl.ConnectionUtilImpl;

public class getDataAndSave {

	public static void main(String[] args) {
		URL url = null;
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		try {
			url = new URL(
					"https://quality.data.gov.tw/dq_download_csv.php?nid=122363&md5_url=88682e3f2c5eb953b9b3c244b921ed6f");
			try (InputStream openStream = url.openStream();
					InputStreamReader ir = new InputStreamReader(openStream);
					BufferedReader br = new BufferedReader(ir)) {
				br.readLine();// 先讀過一次 跳過第一行文字
				String str = "";			
				int count = 0;
				while ((str = br.readLine()) != null) {								// 		System.out.println(str);			
					String[] temp = str.split(","); 								//		for(int i =0;  i<temp.length;i++) {
																					//			System.out.println(temp[i]);
																					//		}					
					////////日期轉換///////
					String dateString = temp[7];
					SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
					Date date = sdf.parse(dateString);	//先把字串轉成 java.util.date				

			        java.sql.Date sqlDate = new java.sql.Date(date.getTime());//再轉成 java.sql.date
			        ////////日期轉換///////
					PreparedStatement pstmt = conn.prepareStatement(
							"INSERT INTO [dbo].[assist_data]\r\n"
							+ "           ([輔助人代碼],[輔助人類型代碼],[組織型態],[輔助人中文名稱]\r\n"
							+ "           ,[輔助人地址],[電話],[營利事業暨扣繳單位統一編號],[公告日期])\r\n"
							+ "VALUES (?,?,?,?,?,?,?,?)");

						pstmt.setString(1, temp[0]);
						pstmt.setString(2, temp[1]);
						pstmt.setInt(3, Integer.valueOf(temp[2]));
						pstmt.setString(4, temp[3]);
						pstmt.setString(5, temp[4]);
						pstmt.setString(6, temp[5]);
						pstmt.setString(7, temp[6]);
						pstmt.setDate(8, sqlDate);
						pstmt.executeUpdate();														//pstmt.addBatch();//pstmt.executeBatch();
						count++;
						pstmt.close();
				}		
				System.out.println(count);
				connUtil.free();
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {		 
			e.printStackTrace();
		}

	}

}
