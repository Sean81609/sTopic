package jdbcUtil.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jdbcUtil.ConnectionUtil;

public class ConnectionUtilImpl implements ConnectionUtil {

	// 連線字串
	// OK
	private String mssqlConnString = "jdbc:sqlserver://localhost:1433;databaseName=STopic";
	// String mysqlConnString="jdbc:mysql://localhost:3306/sakila";
	// 使用者名稱
	private String user = "XXX";
	// 密碼
	private String password = "XXX";
	private Connection conn = null;

	@Override
	public Connection getConnection() {
		if (conn == null) {
			try {
				conn = DriverManager.getConnection(mssqlConnString, user, password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("沒有連線到資料庫");
			}
		}
		return conn;
	}

	@Override
	public boolean free() {
		try {
			if (conn != null) {

				if (!conn.isClosed()) {
					conn.close();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}

}
