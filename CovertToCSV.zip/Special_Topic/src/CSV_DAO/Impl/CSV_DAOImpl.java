package CSV_DAO.Impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import CSV_DAO.Csv;
import CSV_DAO.CsvDAO;
import jdbcUtil.ConnectionUtil;
import jdbcUtil.impl.ConnectionUtilImpl;

public class CSV_DAOImpl implements CsvDAO {
	
	@Override
	public Csv findCsvByID(String id) {
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		Csv c = new Csv();
		try {
			PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM [STopic].[dbo].[assist_data]\r\n"
					+ "	where 輔助人代碼 = ?");	
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			c.set輔助人代碼(id);
			c.set輔助人類型代碼(rs.getString("輔助人類型代碼"));
			c.set組織型態(rs.getInt("組織型態"));
			c.set輔助人中文名稱(rs.getString("輔助人中文名稱"));
			c.set輔助人地址(rs.getString("輔助人地址"));
			c.set電話(rs.getString("電話"));
			c.set營利事業暨扣繳單位統一編號(rs.getString("營利事業暨扣繳單位統一編號"));
			c.set公告日期(rs.getDate("公告日期"));			
			pstmt.close();
			rs.close();
		} catch (SQLException e) {
			c.set輔助人代碼("無此代碼");
			c.set輔助人類型代碼("無此代碼");
			c.set組織型態(0);
			c.set輔助人中文名稱("無此名稱");
			c.set輔助人地址("無此地址");
			c.set電話("無此電話");
			c.set營利事業暨扣繳單位統一編號("無此統一編號");
			c.set公告日期(null);
			e.printStackTrace();
		}finally {
			connUtil.free();
		}
		return c;
	}

	@Override
	public String findAll() {
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		PreparedStatement pstmt;
		String str ="";
		
		try {
			pstmt = conn.prepareStatement("SELECT * FROM assist_data");
			ResultSet rs = pstmt.executeQuery();
			int cols = rs.getMetaData().getColumnCount();
			while(rs.next()) {

				for (int i = 1; i <= cols; i++) {
					str+=rs.getString(i);
					if (i < cols)
						str+=',';
				}
				str+='\n';
			
			}
			pstmt.close();
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connUtil.free();
		}
		return str;
	}

	@Override
	public String getColumnName() {
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		PreparedStatement pstmt;
		String str ="";
		try {
			pstmt = conn.prepareStatement("SELECT * FROM assist_data");
			ResultSet rs = pstmt.executeQuery();			
			int cols = rs.getMetaData().getColumnCount();//計算有幾個欄位
			//////////////寫入SQL欄位名稱//////////////
			
			for (int i = 1; i <= cols; i++) {
				str+=rs.getMetaData().getColumnLabel(i);//取得欄位名稱
				if (i < cols)
					str+=',';
				else
					str+='\n';//換行
			}
			pstmt.close();
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connUtil.free();
		}
			return str;
	}

	@Override
	public boolean createCsv(Csv csv) {
		String sql="INSERT INTO [dbo].[assist_data]\r\n"
				+ "           ([輔助人代碼],[輔助人類型代碼],[組織型態],[輔助人中文名稱]        \r\n"
				+ "           ,[輔助人地址],[電話],[營利事業暨扣繳單位統一編號],[公告日期])   \r\n"
				+ "     VALUES\r\n"
				+ "           (?,?,?,?,?,?,?,?)";
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, csv.get輔助人代碼());
			pstmt.setString(2, csv.get輔助人類型代碼());
			pstmt.setInt(3, csv.get組織型態());
			pstmt.setString(4, csv.get輔助人中文名稱());
			pstmt.setString(5, csv.get輔助人地址());
			pstmt.setString(6, csv.get電話());
			pstmt.setString(7, csv.get營利事業暨扣繳單位統一編號());
			pstmt.setDate(8,  csv.get公告日期());
			int count = pstmt.executeUpdate();
			pstmt.close();
			if(count>0) {
				return true;
			}else {
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connUtil.free();
		}
		return false;
	}

	@Override
	public boolean updateCsv(Csv csv) {
		String sql="UPDATE [dbo].[assist_data]\r\n"
				+ "   SET [輔助人類型代碼] = ?,[組織型態] = ?,[輔助人中文名稱] = ?      \r\n"
				+ "      ,[輔助人地址] = ? ,[電話] = ?,[營利事業暨扣繳單位統一編號] = ?,[公告日期] = ?\r\n"
				+ "   WHERE [輔助人代碼] = ?  "  ;
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(8, csv.get輔助人代碼());
			pstmt.setString(1, csv.get輔助人類型代碼());
			pstmt.setInt(2, csv.get組織型態());
			pstmt.setString(3, csv.get輔助人中文名稱());
			pstmt.setString(4, csv.get輔助人地址());
			pstmt.setString(5, csv.get電話());
			pstmt.setString(6, csv.get營利事業暨扣繳單位統一編號());
			pstmt.setDate(7,  csv.get公告日期());
			int count = pstmt.executeUpdate();
			pstmt.close();
			if(count>0) {
				System.out.println("修改成功");
				return true;
			}else {
				System.out.println("修改失敗");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connUtil.free();
		}
		return false;
	}

	@Override
	public boolean deleteCsv(String id) {
		String sql="DELETE FROM [dbo].[assist_data] WHERE [輔助人代碼] = ? "  ;
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			int count = pstmt.executeUpdate();
			pstmt.close();
			if(count>0) {
				System.out.println("刪除成功");
				return true;
			}else {
				System.out.println("刪除失敗");
				return false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			connUtil.free();
		}
		return false;
	}



}
