package CSV_DAO;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

import CSV_DAO.Impl.CSV_DAOImpl;

public class CsvTest {

	public static void main(String[] args) {
		CsvDAO c = new CSV_DAOImpl();
		String select = JOptionPane.showInputDialog("輸入操作:\n1.查詢資料(輔助人代碼)\n2.查詢資料(全)\n3.新增\n4.修改\n5.刪除");
		switch (select) {
		case "1": {//查尋

			File f = new File("C:/Users/Sean/Desktop/Topic/查詢資料(輔助人代碼).csv");
			String codeStr = JOptionPane.showInputDialog("輸入輔助人代碼:");
				/////

			Csv csv_1 = c.findCsvByID(codeStr);
			if (csv_1.get輔助人代碼() == "無此代碼") {
				System.out.println(csv_1.toString());
				JOptionPane.showMessageDialog(null, "無此代碼", "錯誤", JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			System.out.println(csv_1.toString());
				/////  if (result==JOptionPane.YES_OPTION) {System.exit(0);}   
			String str = JOptionPane.showInputDialog("是否印出: 1.是 2.否");
			int toPrint = Integer.parseInt(str);
			if (toPrint == 1) {
				try (FileOutputStream fos = new FileOutputStream(f);
						OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
						BufferedWriter bw = new BufferedWriter(osw);) {
					CsvDAO c2 = new CSV_DAOImpl();
					String col = c2.getColumnName();
					bw.write(col);
					bw.write(csv_1.toString());
					System.out.println("OK");
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (toPrint == 2) {
				JOptionPane.showMessageDialog(null, "取消印出");
			} else {
				JOptionPane.showMessageDialog(null, "無此選項", "錯誤", JOptionPane.WARNING_MESSAGE);
			}


			break;
		}
		case "2": {//查尋全部
			File f = new File("C:/Users/Sean/Desktop/Topic/查詢資料(全).csv");
			String csv_2 = c.findAll();
			System.out.println(csv_2);
			///// if (result==JOptionPane.YES_OPTION) {System.exit(0);}
			String str = JOptionPane.showInputDialog("是否印出: 1.是 2.否");
			int toPrint = Integer.parseInt(str);
			if (toPrint == 1) {
				try (FileOutputStream fos = new FileOutputStream(f);
						OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
						BufferedWriter bw = new BufferedWriter(osw);) {
					CsvDAO c2 = new CSV_DAOImpl();
					String col = c2.getColumnName();// 取得欄位物件
					bw.write(col);
					bw.write(csv_2);
					System.out.println("OK");
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (toPrint == 2) {
				JOptionPane.showMessageDialog(null, "取消印出");
			} else {
				JOptionPane.showMessageDialog(null, "無此選項", "錯誤", JOptionPane.WARNING_MESSAGE);
			}
			
			break;
		}
		case "3":{//新增
			
			Csv new_csv=new Csv();
			try {
				String dateString = "20221106";
				SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
				Date date= sdf.parse(dateString);;
				java.sql.Date sqlDate = new java.sql.Date(date.getTime());//sqlDate轉換
				new_csv.set輔助人代碼("C8763");
				new_csv.set輔助人類型代碼("Star");
				new_csv.set組織型態(8);
				new_csv.set輔助人中文名稱("桐仁");
				new_csv.set輔助人地址("艾恩格朗特22層小木屋");
				new_csv.set電話("0987638763");
				new_csv.set營利事業暨扣繳單位統一編號("4876348763");
				new_csv.set公告日期(sqlDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
			boolean isCreated = c.createCsv(new_csv);
			System.out.println(isCreated);
			break;
		}
		case"4":{//修改
			
			String codeStr = JOptionPane.showInputDialog("輸入要修改的輔助人代碼:");
			Csv csv_1 = c.findCsvByID(codeStr);
			csv_1.set輔助人中文名稱("小倩");
			csv_1.set組織型態(763);
			boolean update = c.updateCsv(csv_1);
			System.out.println(update);
			break;
		}
		case "5":{//刪除
			String codeStr = JOptionPane.showInputDialog("輸入要刪除的輔助人代碼:");
			boolean delete = c.deleteCsv(codeStr);
			System.out.println(delete);
			break;
		}
			
		default:
			JOptionPane.showMessageDialog(null, "無此選項", "錯誤", JOptionPane.WARNING_MESSAGE);
			break;
		
		}

		
	}
}
