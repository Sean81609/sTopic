package CSV_DAO;

public interface CsvDAO {
	
	//CRUD
	String getColumnName();//讀取欄位
	Csv findCsvByID(String id);//查詢(ID)
	String findAll();//查詢(全部)
	boolean createCsv(Csv csv);//新增
	boolean updateCsv(Csv csv);//修改
	boolean deleteCsv(String id);//刪除
}
