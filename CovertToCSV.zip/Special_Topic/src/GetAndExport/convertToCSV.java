package GetAndExport;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbcUtil.ConnectionUtil;
import jdbcUtil.impl.ConnectionUtilImpl;

public class convertToCSV {

	public static void main(String[] args) {
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection conn = connUtil.getConnection();
		File f = new File("C:/Users/Sean/Desktop/Topic/目標檔案.csv");
		
		try (FileOutputStream fos = new FileOutputStream(f);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
			BufferedWriter bw = new BufferedWriter(osw);){
			PreparedStatement pstmt = conn.prepareStatement("SELECT *\r\n" + "FROM [STopic].[dbo].[assist_data]    ");
			ResultSet rs = pstmt.executeQuery();

			
			int cols = rs.getMetaData().getColumnCount();//計算有幾個欄位
			//////////////寫入SQL欄位名稱//////////////
			for (int i = 1; i <= cols; i++) {
				bw.write(rs.getMetaData().getColumnLabel(i));//取得欄位名稱
				if (i < cols)
					bw.write(',');
				else
					bw.write('\n');//換行
			}
			//////////////寫入SQL欄位名稱//////////////
			
			
			while (rs.next()) {

				for (int i = 1; i <= cols; i++) {
					bw.write(rs.getString(i));
					if (i < cols)
						bw.write(',');
				}
				bw.write('\n');
			}
			System.out.println("轉換OK");
			rs.close();
			connUtil.free();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			 System.out.println("SQL查詢失敗");
			 System.out.println("Message:"+e.getMessage());
			e.printStackTrace();
		}

	}

}
