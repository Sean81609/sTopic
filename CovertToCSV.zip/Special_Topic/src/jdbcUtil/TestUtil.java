package jdbcUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jdbcUtil.impl.ConnectionUtilImpl;

public class TestUtil {

	public static void main(String[] args) {
		ConnectionUtil connUtil = new ConnectionUtilImpl();
		Connection connection = connUtil.getConnection();
		
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT TOP (1000) [ShipperID]\r\n"
												+ "      ,[CompanyName]\r\n"
												+ "      ,[Phone]\r\n"
												+ "  FROM [Northwind].[dbo].[Shippers]");
			if(rs!=null) {
				System.out.println("Test ok");
			}else {
				System.out.println("NG");
			}
			connUtil.free();
			if(connection.isClosed()) {
				System.out.println("free OK");
			}else {
				System.out.println("not free");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
