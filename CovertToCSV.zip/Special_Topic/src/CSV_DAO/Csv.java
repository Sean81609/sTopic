package CSV_DAO;

import java.io.Serializable;
import java.util.Date;

public class Csv implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String 輔助人代碼;
	private String 輔助人類型代碼;
	private Integer 組織型態;
	private String 輔助人中文名稱;
	private String 輔助人地址;
	private String 電話;
	private String 營利事業暨扣繳單位統一編號;
	private Date 公告日期;
	/**
	 * @return the 輔助人代碼
	 */
	public String get輔助人代碼() {
		return 輔助人代碼;
	}
	/**
	 * @param 輔助人代碼 the 輔助人代碼 to set
	 */
	public void set輔助人代碼(String 輔助人代碼) {
		this.輔助人代碼 = 輔助人代碼;
	}
	/**
	 * @return the 輔助人類型代碼
	 */
	public String get輔助人類型代碼() {
		return 輔助人類型代碼;
	}
	/**
	 * @param 輔助人類型代碼 the 輔助人類型代碼 to set
	 */
	public void set輔助人類型代碼(String 輔助人類型代碼) {
		this.輔助人類型代碼 = 輔助人類型代碼;
	}
	/**
	 * @return the 組織型態
	 */
	public Integer get組織型態() {
		return 組織型態;
	}
	/**
	 * @param 組織型態 the 組織型態 to set
	 */
	public void set組織型態(Integer 組織型態) {
		this.組織型態 = 組織型態;
	}
	/**
	 * @return the 輔助人中文名稱
	 */
	public String get輔助人中文名稱() {
		return 輔助人中文名稱;
	}
	/**
	 * @param 輔助人中文名稱 the 輔助人中文名稱 to set
	 */
	public void set輔助人中文名稱(String 輔助人中文名稱) {
		this.輔助人中文名稱 = 輔助人中文名稱;
	}
	/**
	 * @return the 輔助人地址
	 */
	public String get輔助人地址() {
		return 輔助人地址;
	}
	/**
	 * @param 輔助人地址 the 輔助人地址 to set
	 */
	public void set輔助人地址(String 輔助人地址) {
		this.輔助人地址 = 輔助人地址;
	}
	/**
	 * @return the 電話
	 */
	public String get電話() {
		return 電話;
	}
	/**
	 * @param 電話 the 電話 to set
	 */
	public void set電話(String 電話) {
		this.電話 = 電話;
	}
	/**
	 * @return the 營利事業暨扣繳單位統一編號
	 */
	public String get營利事業暨扣繳單位統一編號() {
		return 營利事業暨扣繳單位統一編號;
	}
	/**
	 * @param 營利事業暨扣繳單位統一編號 the 營利事業暨扣繳單位統一編號 to set
	 */
	public void set營利事業暨扣繳單位統一編號(String 營利事業暨扣繳單位統一編號) {
		this.營利事業暨扣繳單位統一編號 = 營利事業暨扣繳單位統一編號;
	}
	/**
	 * @return the 公告日期
	 */
	public java.sql.Date get公告日期() {
		return (java.sql.Date) 公告日期;
	}
	/**
	 * @param 公告日期 the 公告日期 to set
	 */
	public void set公告日期(Date 公告日期) {
		this.公告日期 = 公告日期;
	}
	@Override
	public String toString() {
		//"輔助人代碼,輔助人類型代碼,組織型態,輔助人中文名稱,輔助人地址,電話,營利事業暨扣繳單位統一編號,公告日期\n"+
		return  輔助人代碼 + "," + 輔助人類型代碼 + "," + 組織型態 + "," + 輔助人中文名稱 + ","
				+ 輔助人地址 + "," + 電話 + "," + 營利事業暨扣繳單位統一編號 + "," + 公告日期+"\n";
	}
	
	
}
